# Description

The resource is used to manage SMB Server Settings.

## Requirements

Windows Server 2012 or newer.
