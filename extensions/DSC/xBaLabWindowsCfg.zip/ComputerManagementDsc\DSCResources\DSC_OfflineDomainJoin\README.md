# Description

The resource allows you to join computers to an Active Directory domain using an
[Offline Domain Join](https://technet.microsoft.com/en-us/library/offline-domain-join-djoin-step-by-step(v=ws.10).aspx)
request file.
